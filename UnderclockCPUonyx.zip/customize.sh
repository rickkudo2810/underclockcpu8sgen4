# Set quyền thực thi cho service.sh
set_perm $MODPATH/service.sh 0 0 0755